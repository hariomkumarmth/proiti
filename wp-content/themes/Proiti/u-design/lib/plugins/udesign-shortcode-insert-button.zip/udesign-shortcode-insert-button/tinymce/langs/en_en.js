tinyMCE.addI18n({en_US:{
udesignShortcodeInsert:{	
desc : 'Insert a U-Design Shortcode'
}}});